from flask import render_template

@reports_bp.route("/expenses")
def expenses_report():
    # Fetch data and calculate expenses here
    return render_template("expenses_report.html")

@reports_bp.route("/wages")
def wages_report():
    # Fetch data and calculate wages here
    return render_template("wages_report.html")
