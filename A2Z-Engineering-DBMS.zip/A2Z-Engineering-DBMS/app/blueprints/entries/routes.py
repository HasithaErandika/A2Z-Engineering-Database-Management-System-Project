from flask import render_template, request, redirect, url_for, flash
from app.models import Entry
from app import db

@entries_bp.route("/add", methods=["GET", "POST"])
def add_entry():
    if request.method == "POST":
        name = request.form["name"]
        details = request.form["details"]
        entry = Entry(name=name, details=details)
        db.session.add(entry)
        db.session.commit()
        flash("Entry added successfully!", "success")
        return redirect(url_for("entries.dashboard"))

    return render_template("add_entry.html")

@entries_bp.route("/delete/<int:id>")
def delete_entry(id):
    entry = Entry.query.get_or_404(id)
    db.session.delete(entry)
    db.session.commit()
    flash("Entry deleted successfully!", "success")
    return redirect(url_for("entries.dashboard"))

@entries_bp.route("/")
def dashboard():
    entries = Entry.query.all()
    return render_template("dashboard.html", entries=entries)
