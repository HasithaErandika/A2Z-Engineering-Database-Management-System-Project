import os

SECRET_KEY = os.urandom(24)
SQLALCHEMY_DATABASE_URI = 'postgresql://username:password@localhost/suramalr_operational_db'
