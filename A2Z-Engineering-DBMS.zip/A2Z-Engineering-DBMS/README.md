A2Z-Engineering-DBMS/
├── app/
│   ├── __init__.py
│   ├── blueprints/
│   │   ├── __init__.py
│   │   ├── auth/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       └── login.html
│   │   ├── entries/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       ├── add_entry.html
│   │   │       ├── delete_entry.html
│   │   │       └── update_entry.html
│   │   ├── materials/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       ├── materials_list.html
│   │   │       └── material_find.html
│   │   ├── reports/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       ├── expenses_report.html
│   │   │       └── wages_report.html
│   │   ├── invoices/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       ├── view_invoice.html
│   │   │       └── generate_invoice.html
│   │   ├── tables/
│   │   │   ├── __init__.py
│   │   │   ├── routes.py
│   │   │   └── templates/
│   │   │       └── tables.html
│   ├── static/
│   │   ├── css/
│   │   │   └── styles.css
│   │   ├── js/
│   │   │   └── scripts.js
│   ├── templates/
│   │   ├── base.html
│   │   ├── header.html
│   │   └── footer.html
│   └── models.py
├── instance/
│   └── config.py
├── migrations/
├── logs/
│   └── error.log
├── tests/
│   ├── __init__.py
│   ├── test_auth.py
│   ├── test_entries.py
│   ├── test_reports.py
│   └── test_materials.py
├── config.py
├── requirements.txt
├── README.md
├── run.py
└── .env
